#ifndef MAP_H
#define MAP_H

#include "Graphics.h";

class Map {
   public:
     // void initializeMapFromSVG(const std::string& svgFilePath);


};

#endif