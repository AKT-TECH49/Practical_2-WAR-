#ifndef STATE_H
#define STATE_H

struct State {
    int healthPerSoldier;
    int damagePerSoldier;
    int defencePerSoldier;
    int amountOfSoldiersPerUnit;
};

#endif // STATE_H
