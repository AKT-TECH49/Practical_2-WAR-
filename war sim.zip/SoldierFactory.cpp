#include "SoldierFactory.h"

