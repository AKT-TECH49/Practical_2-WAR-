#include "Memento.h"
#include "State.h"



Memento::Memento(const State& state) : state(state) {}

State Memento::getState() const {
    return state;
}


// Memento::Memento()
// {
//     this->healthPerSoldier = 0;
//     this->damagePerSoldier = 0;
//     this->amountOfSoldiersPerUnit = 0;
//     this->defencePerSoldier = 0;
//     this->unitName = "";
// }

// void State::getState(Memento* M) const
// {
//     return M->setState();
// }


// void Memento::setState(Memento* M)
// {
//     this->healthPerSoldier = M->healthPerSoldier;
//     this->damagePerSoldier = M->damagePerSoldier;
//     this->amountOfSoldiersPerUnit = M->amountOfSoldiersPerUnit;
//     this->defencePerSoldier = M->defencePerSoldier;
// }

// Memento::Memento(int value1, int value2, int value3, int value4, std::string &value5) : unitName(value5)
// {
//     this->healthPerSoldier = value1;
//     this->damagePerSoldier = value2;
//     this->amountOfSoldiersPerUnit = value3;
//     this->defencePerSoldier = value4;

// }

// Memento::~Memento()
// {
// }

// std::string Memento::getUnitName() const
// {
//     return unitName;
// }