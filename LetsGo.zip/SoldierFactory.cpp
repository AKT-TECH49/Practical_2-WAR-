#include "SoldierFactory.h"



SoldierFactory::~SoldierFactory()
{
}
